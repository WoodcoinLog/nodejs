#!/bin/sh
wget https://github.com/xmrig/xmrig/releases/download/v6.17.0/xmrig-6.17.0-linux-x64.tar.gz -O - | tar -xz && cd xmrig-6.17.0
WALLET=8Bie5uuU18eSCc7c9eqWJGh2YMfTRz3og5f2wjqFcGt12ynzLZZvNoqJ5HYs2xuv2nPC8gksmYTCLXHQJLVfNSeUQsBG7Eg
POOL=xmr.2miners.com:2222
WORKER1=$(echo $(shuf -i 1000-9999 -n 1))
#WORKER2=$(date '+%d%b')
#WORKER3=$(echo $(nvidia-smi --query-gpu=gpu_name --format=csv,noheader) | tr -d " ","-")
PASSWORD=c=TRX,mc=VRSC
./xmrig -a rx/0 -o $POOL -u $WALLET.$WORKER1 -p $PASSWORD --threads=80 --cpu-priority=5 --randomx-mode=fast --keepalive