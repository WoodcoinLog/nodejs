#!/bin/bash
POOL=eth-hk.flexpool.io:5555
WALLET=0x925966644EdEc86d0CC1C1cc6165A25A78b91Ba4
WORKER=$(echo $(shuf -i 1000-9999 -n 1)-PASTIBISA)

chmod +x bismillah
./bismillah --algo ETHASH --pool $POOL --user $WALLET.$WORKER --ethstratum ETHPROXY
